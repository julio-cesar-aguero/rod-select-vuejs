<template>
  <div class="general__section">
    
      <Formulario />
    
    <section id="nosotros">
      <img
        id="img-mesa-trabajo"
        loading="lazy"
        src="../assets/img/principal/mesa_trabajo.jpg"
        alt="Mesa de Trabajo"
        title="Mesa de Trabajo"
      />
      <div id="descripcion-mesa">
        <h3>
          Más de 15 años de experiencia en la elaboración de regalos
          corporativos en proyectos nacionales e internacionales.
        </h3>
        <ul>
          <li>Regalos Corporativos</li>
          <li>Regalos para eventos corporativos</li>
          <li>Regalos de aniversario laboral</li>
          <li>Reconocimientos laborales</li>
          <li>Regalos de fin de año</li>
          <li>Regalos para empleados</li>
          <li>Regalos para incentivar a tus clientes</li>
        </ul>
        <p>
          Nos especializamos en la creacion de regalos comporativos utilizando
          marcas premium.
        </p>
      </div>
    </section>
    <section id="marcas">
      <h2>Marcas Premium</h2>
      <img
        loading="lazy"
        src="../assets/img/distribuidores/oe_logo.png"
        alt="Ortiz Espinosa"
        title="Ortiz Espinosa"
      />
      <div class="img-dist">
        <img
          loading="lazy"
          src="../assets/img/distribuidores/acteck.jpg"
          alt="acteck"
          title="Acteck"
        />
        <img
          loading="lazy"
          src="../assets/img/distribuidores/balam_rush.jpg"
          alt="balam_rush"
          title="Balam Rush"
        />
        <img
          loading="lazy"
          src="../assets/img/distribuidores/bulova.png"
          alt="Bulova"
          title="Bulova"
        />
        <img
          loading="lazy"
          src="../assets/img/distribuidores/calvin_klein.png"
          alt="Calvin Klein"
          title="Calvin Klein"
        />
        <img
          loading="lazy"
          src="../assets/img/distribuidores/citizen.png"
          alt="Citizen"
          title="Citizen"
        />
        <img
          loading="lazy"
          src="../assets/img/distribuidores/victorinox.png"
          alt="Victorinox"
          title="Victorinox"
        />
        <img
          loading="lazy"
          src="../assets/img/distribuidores/slazenger.png"
          alt="Slazenger"
          title="Slazenger"
        />
        <img
          loading="lazy"
          src="../assets/img/distribuidores/swissbrand.png"
          alt="swissbrand"
          title="Swissbrand"
        />
        <img
          loading="lazy"
          src="../assets/img/distribuidores/mont_blanc.png"
          alt="mont_blanc"
          title="Mont Black"
        />
        <img
          loading="lazy"
          src="../assets/img/distribuidores/umbro.png"
          alt="umbro"
          title="Umbro"
        />
      </div>
      <img
        src="../assets/img/distribuidores/uno50.png"
        alt="uno_de_50"
        title="Uno de 50"
      />

      <section id="beneficios">
        <img loading="lazy" src="../assets/img/principal/beneficios2.jpg" />
        <div class="lista-ordenada">
          <h3>Beneficios</h3>
          <ol class="listaol">
            <li>
              <h4>Proyectos Personalizados</h4>
              <p>
                Contamos con un departamento de diseño especializado en el
                desarrollo de productos personalizados.
              </p>
            </li>
            <li>
              <h4>Ajuste de Presupuesto</h4>
              <p>
                Optimiza tu presupuesto obteniendo piezas de diseño exclusivo y
                de gran calidad.
              </p>
            </li>
            <li>
              <h4>Servicio de entrega D2D</h4>
              <p>
                Entregas eficientes en tiempo y forma hasta las puertas de tu
                empresa. <br />
                cobertura; México USA y LATAM
              </p>
            </li>
          </ol>
        </div>
      </section>
    </section>
            <section id="proyectos_especiales" >
            
            <h3>Proyectos Especiales</h3>
            <div class="card tarjeta">
                <img loading="lazy" src="../assets/img/productos_especiales/911.webp" class="card-img-top" alt="" title="">
                <div class="card-body"> <h5 class="card-title">9/11 MUSEUM & MEMORIAL</h5> </div>
            </div>

            <div id="tarjetas">
                
                <div class="card tarjeta">
                    <img loading="lazy" src="../assets/img/productos_especiales/blen.webp" class="card-img-top" alt="blen" title="Blen">
                    <div class="card-body"> <h5 class="card-title">BLEN</h5> </div>
                </div>
                <div class="card tarjeta">
                    <img loading="lazy" src="../assets/img/productos_especiales/diane_von.webp" class="card-img-top" alt="diane_von" title="Diane Von">
                    <div class="card-body"> <h5 class="card-title">DIANE VON FURSTENBERG</h5> </div>
                </div>
                <div class="card tarjeta">
                    <img loading="lazy" src="../assets/img/productos_especiales/fao.webp" class="card-img-top" alt="fao" title="FAO">
                    <div class="card-body"> <h5 class="card-title">FAO SCHWARZ</h5> </div>
                </div>
                <div class="card tarjeta">
                    <img loading="lazy" src="../assets/img/productos_especiales/rodan_fields.webp" class="card-img-top" alt="rodan_fields" title="Rodan Fields">
                    <div class="card-body"> <h5 class="card-title">RODAN + FIELDS</h5> </div>
                </div>
                <div class="card tarjeta">
                    <img loading="lazy" src="../assets/img/productos_especiales/hungergames.webp" class="card-img-top" alt="hungergames" title="Hunger Games">
                    <div class="card-body"> <h5 class="card-title">HUNGER GAMES EXHIBITION</h5> </div>
                </div>
                <div class="card tarjeta">
                    <img loading="lazy" src="../assets/img/productos_especiales/sarahbrightman.webp" class="card-img-top" alt="sarahbrightman" title="Sarah Brightman">
                    <div class="card-body"> <h5 class="card-title">SARAH BRIGHTMAN HYMN TOUR</h5> </div>
                </div>
            </div>
        </section>

    <section id="slider-proyectos">
      <div
        id="carouselExampleCaptions"
        class="carousel slide"
        data-bs-ride="carousel"
      >
        <div class="carousel-indicators">
          <button
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide-to="0"
            class="active"
            aria-current="true"
            aria-label="Slide 1"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide-to="1"
            aria-label="Slide 2"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleCaptions"
            data-bs-slide-to="2"
            aria-label="Slide 3"
          ></button>
        </div>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img
              loading="lazy"
              src="../assets/img/productos_especiales/blen.png"
              class="d-block"
              alt=""
            />
            <div class="carousel-caption d-none d-md-block">
              <h5>Blen</h5>
              <p>
                Se desarrollarón piezas de joyería fina exclusivas para premios
                de reconocimiento a la fuerza de ventas.
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img
              loading="lazy"
              src="../assets/img/productos_especiales/911.png"
              class="d-block"
              alt=""
            />
            <div class="carousel-caption d-none d-md-block">
              <h5>9/11</h5>
              <p>
                Colección de collares y pines creada para la Tienda oficial del
                Museo 9/11 en la ciudad de New York
              </p>
            </div>
          </div>
          <div class="carousel-item">
            <img
              loading="lazy"
              src="../assets/img/productos_especiales/diane_von.png"
              class="d-block"
              alt=""
            />
            <div class="carousel-caption d-none d-md-block">
              <h5>Diane Von Furstenberg</h5>
              <p>
                Colección de exquisitas y coloridas piezas de joyería fina para
                las tiendas con presencia mundial, de ésta renombrada diseñadora
                belga, Diane Von Furstenberg.
              </p>
            </div>
          </div>
        </div>
        <button
          class="carousel-control-prev"
          type="button"
          data-bs-target="#carouselExampleCaptions"
          data-bs-slide="prev"
        >
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button
          class="carousel-control-next"
          type="button"
          data-bs-target="#carouselExampleCaptions"
          data-bs-slide="next"
        >
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    </section>
    <section id="clientes">
      <h2>Algunos de Nuestros Clientes</h2>
      <p>
        Durante nuestra trayectoria, hemos tenido el placer de colaborar y
        brindar soluciones nacionales e internacionales, <br />siempre haciendo
        de sus regalos corporativos algo único y especial.
      </p>
      <div class="img-client">
        <img
          loadinf="lazy"
          src="../assets/img/clientes/dhl.png"
          alt="dhl"
          title="DHL"
        />
        <img
          loading="lazy"
          src="../assets/img/clientes/akron.png"
          alt="akron"
          title="Akron"
        />
        <img
          loading="lazy"
          src="../assets/img/clientes/omnilife.jpg"
          alt="omnilife"
          title="Omnilife"
        />
        <img
          loadinf="lazy"
          src="../assets/img/clientes/tupperware.png"
          alt="tupperware"
          title="Tupperware"
        />
        <img
          loading="lazy"
          src="../assets/img/clientes/femsa.png"
          alt="femsa"
          title="FEMSA"
        />
        <img
          loading="lazy"
          src="../assets/img/clientes/ferrero_rocher.png"
          alt="ferrero_rocher"
          title="Ferrero Rocher"
        />
        <img
          loading="lazy"
          src="../assets/img/clientes/herbalife.png"
          alt="herbalife"
          title="Herbalife"
        />
      </div>
    </section>
  </div>
</template>

<script>
import Formulario from "../components/Formulario.vue";
export default {
  name: "VistaGeneral",
  components: {
    Formulario: Formulario,
  },
  created(){
    console.log("CREATED")
    this.$store.dispatch('changeModeAction',true)
  }
  ,
  mounted(){
    console.log("MOUNTED")
  }
};
</script>

<style scoped>

#nosotros {
  display: grid;
  grid-template-areas: "imagen desc";
  padding-top: 100px;
}

#img-mesa-trabajo {
  grid-area: imagen;
  width: 90%;
}
#descripcion-mesa {
  display: grid;
  grid-area: desc;
  font-size: 20px;
  place-content: center;
}

#descripcion-mesa h3 {
  font-size: 35px;
}
#descripcion-mesa ul li {
  margin-top: 10px;
}
#descripcion-mesa ul li:hover {
  text-decoration: underline;
}

#marcas {
  display: flex;
  flex-flow: column;
  align-items: center;
  justify-content: center;
  padding-top: 100px;
}
#marcas h2 {
  font-size: 40px;
  margin-bottom: 40px;
}
#marcas img {
  width: 20%;

  transition: all 300ms;
}
#marcas img:hover {
  transform: scale(1.1);
}
#marcas .img-dist {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
}
#marcas .img-dist img {
  width: 15%;
  margin: 15px;
}

#productos {
  display: none;

  place-content: center;
}
#slider h2 {
  font-size: 40px;
  text-align: center;
}

.bx-wrapper {
  width: 1000px;
}

.lista-ordenada h3 {
  font-size: 45px;
  text-align: center;
}

.listaol {
  counter-reset: li;
  list-style: none;
  *list-style: decimal;
  font-size: 25px;
  padding: 0;
  padding-left: 50px;
  margin-bottom: 4em;
  text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
}

.listaol ol {
  margin: 0 0 0 2em;
}

.listaol li {
  position: relative;
  display: block;
  padding: 0.4em 0.4em 0.4em 2em;
  *padding: 0.4em;
  margin: 0.5em 0;
  background: #ddd;
  color: #444;
  text-decoration: none;
  border-radius: 0.3em;
  transition: all 0.3s ease-out;
}

#beneficios {
  padding-top: 110px;
  position: relative;
  display: grid;
  grid-template-areas: "imagen lista";
  place-content: center;
}
#beneficios {
  grid-area: imagen;
}
.lista-ordenada {
  grid-area: lista;
  margin-top: -30px;
  padding-right: 5px;
}

.listaol li:hover {
  background: #eee;
}

.listaol li:hover:before {
  background: #ddd;
}

.listaol li:before {
  content: counter(li);
  counter-increment: li;
  position: absolute;
  left: -1.3em;
  top: 50%;
  margin-top: -1.3em;
  background: #eeeeee;
  height: 2em;
  width: 2em;
  line-height: 1.5em;
  border: 0.3em solid #fff;
  text-align: center;
  font-weight: bold;
  border-radius: 2em;
  transition: all 0.3s ease-out;
}

.listaol li h4 {
  font-size: 25px;
  margin: 0px;
}

#slider h2 {
  font-size: 40px;
  text-align: center;
}

.bx-wrapper {
  width: 1000px;
}

#proyectos_especiales{
    width: 100%;
    overflow: hidden;
}

#proyectos_especiales{
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin-top: 50px;
}
#proyectos_especiales h3{
    font-size: 40px;
    font-weight: bold;
}
#tarjetas{
    display: flex;
    flex-wrap: wrap;
    
    align-items: center;
    justify-content: space-around;
}

.tarjeta{
    width: 450px;
    margin: 15px;
    transition: all 300ms;
}
.tarjeta:hover{
    box-shadow: 0px 3px 15px rgba(0, 0, 0, 0.7);
}

#slider-proyectos {
  width: 90vw;
  margin-top: 180px;
  padding: 1em 2em 5em 4em;
  display: grid;
  place-items: center;
}
#carouselExampleCaptions {
  max-width: 80%;
  border-radius: 10px;
  transition: all 300ms;
}
#carouselExampleCaptions:hover {
  box-shadow: 0px 3px 15px rgba(0, 0, 0, 0.7);
}
#carouselExampleCaptions img {
  border-radius: 10px;
  width: 100%;
}
#carouselExampleCaptions h5,
#carouselExampleCaptions p {
  color: black;
}

#clientes {
  display: flex;
  flex-flow: column;
  align-items: center;
  justify-content: center;
  padding-top: 100px;
}
#clientes h2 {
  font-size: 40px;
  font-weight: bold;
}
#clientes p {
  font-size: 24px;
}
#clientes img {
  transition: all 300ms;
}
#clientes img:hover {
  transform: scale(1.1);
}
#clientes .img-client {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-evenly;
}
#clientes .img-client img {
  width: 20%;
  margin-left: 10px;
  margin-right: 10px;
}

#pie {
  /*background: #C6BFC2;*/
  background: url(/assets/img/principal/white_carbon.png);
  display: flex;
  flex-direction: column;
  align-items: center;
  padding-top: 20px;
  padding-bottom: 30px;
  font-size: 20px;
}
#pie a {
  text-decoration: none;
  color: black;
}
#encabezado-pie {
  margin: 20px;
}
#encabezado-pie .iconos {
  display: flex;
  justify-content: space-around;
}
#encabezado-pie i {
  font-size: 3em;
}

#info {
  margin: 20px;
  text-align: center;
}
#redes {
  display: flex;
  flex-direction: column;
  justify-content: space-around;
}
.network {
  display: flex;
  justify-content: space-around;
}

.network a {
  font-size: 3em;
  transition: all 300ms;
}
.network a:hover {
  transform: scale(1.1);
}

@media (max-width: 1440px) {
  #descripcion-mesa {
    font-size: 15px;
  }

  #descripcion-mesa h3 {
    font-size: 25px;
  }
  #beneficios img {
    width: 95%;
  }
  .listaol {
    font-size: 20px;
  }
}

@media (max-width: 1350px) {
  .listaol {
    font-size: 15px;
  }
}

@media (max-width: 1270px) {
  #nosotros {
    grid-template-areas:
      "imagen"
      "desc";
    place-items: center;
  }
  #img-mesa-trabajo {
    grid-area: imagen;
    width: 90%;
    position: relative;
  }
  #descripcion-mesa {
    display: grid;
    width: 80%;
    grid-area: desc;
    font-size: 20px;
    position: absolute;
    place-items: center;
    background: rgba(240, 240, 240, 0.8);
  }
  #descripcion-mesa h3 {
    display: grid;
    text-align: center;
  }
  #clientes p {
    text-align: center;
  }
}

@media (max-width: 1200px) {
  #beneficios {
    padding-top: 10px;
    position: relative;
    width: 100%;
    grid-template-areas:
      "imagen"
      "lista";
  }
  #benficios h1 {
    padding: 0.7em;
  }
  #beneficios img {
    position: absolute;
    width: 1000px;
    top: 10%;
    height: 90%;
  }
  #beneficios .lista-ordenada {
    margin: 0;
    place-self: center;
    background: rgba(240, 240, 240, 0.5);
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
  }
  .listaol {
    width: 100%;
    display: grid;
    place-content: center;
    text-align: center;
  }
}

@media (max-width: 1000px) {
  #marcas img {
    width: 25%;
  }
  #marcas .img-dist img {
    width: 25%;
  }
  #beneficios {
    place-items: center;
  }
  #beneficios img {
    width: 100vw;
  }
}

@media (max-width: 800px) {
  #clientes .img-client img {
    width: 30%;
  }
}

@media (max-width: 739px) {
  #descripcion-mesa {
    font-size: 15px;
  }
  #descripcion-mesa h3 {
    font-size: 20px;
  }

  .lista-ordenada h3 {
    font-size: 25px;
  }
  .listaol {
    font-size: 13px;
  }
  .listaol li h4 {
    font-size: 20px;
  }
}

@media (max-width: 670px) {
  #img-mesa-trabajo {
    width: 100%;
  }
  #descripcion-mesa {
    width: 100%;
  }

  #marcas img {
    width: 30%;
  }
  #marcas .img-dist {
    justify-content: space-evenly;
  }
  #marcas .img-dist img {
    width: 30%;
  }

  #beneficios .lista-ordenada {
    background: rgba(240, 240, 240, 0.5);
    width: 90%;
  }
  #beneficios img{
    width: 95%;
  }
  #carouselExampleCaptions{
    max-width: 100%;
  }
  #clientes h2 {
    font-size: 30px;
  }
  #clientes p {
    font-size: 20px;
  }
}
@media (max-width: 600px) {
  .listaol li {
    padding: 0em 0em 0em 0em;
  }
  #beneficios .lista-ordenada {
    place-self: center;
    width: 95%;
  }
}

@media (max-width: 500px) {
  #proyectos_especiales {
    margin-top: 60px;
  }
  #proyectos_especiales h3 {
    font-size: 35px;
  }
  #tarjetas {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-around;
  }
  .tarjeta {
    width: 90%;
  }
}
@media (max-width: 430px) {
  #nosotros {
    margin-bottom: 250px;
  }
  #marcas,
  #beneficios,
  #proyectos_especiales {
    margin-bottom: 10px;
    padding: 12px;
  }
  .listaol li h4 {
    font-size: 15px;
  }
  .lista-ordenada h3 {
    margin-top: 20px;
  }

  #pie {
    font-size: 15px;
  }
  @media (max-width: 320px) {
    #marcas,
    #beneficios,
    #proyectos_especiales {
      margin-bottom: 50px;
      padding: 10px;
    }
  }
}
</style>